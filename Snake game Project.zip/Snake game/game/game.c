#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>  
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480
#define GRID_SIZE 20
#define SNAKE_MAX_LENGTH 100

// Paths to images
const char *backgroundPath = "bcg.jpg";   
const char *snakeTexturePath = "ball.png";  
const char *foodTexturePath = "apple.png";  
const char *fontPath = "arial.ttf";          

// Structs for snake and food
typedef struct {
    int x, y;
} Point;

typedef struct {
    Point body[SNAKE_MAX_LENGTH];
    int length;
    Point direction;
} Snake;

// Function prototypes
SDL_Texture* loadTexture(SDL_Renderer *renderer, const char *file);
void initializeSDL(SDL_Window **window, SDL_Renderer **renderer, TTF_Font **font);
void cleanup(SDL_Window *window, SDL_Renderer *renderer, SDL_Texture *bgTexture, SDL_Texture *snakeTexture, SDL_Texture *foodTexture, TTF_Font *font);
void renderBackground(SDL_Renderer *renderer, SDL_Texture *bgTexture);
void renderSnake(SDL_Renderer *renderer, Snake *snake, SDL_Texture *snakeTexture);
void renderFood(SDL_Renderer *renderer, Point *food, SDL_Texture *foodTexture);
void renderScore(SDL_Renderer *renderer, TTF_Font *font, int score);
void renderGameOver(SDL_Renderer *renderer, TTF_Font *font);
void renderBorders(SDL_Renderer *renderer);
void renderIntroScreen(SDL_Renderer *renderer, TTF_Font *font);
void moveSnake(Snake *snake);
bool checkCollision(Snake *snake, Point *food);
bool checkSelfCollision(Snake *snake);
bool checkBorderCollision(Snake *snake);
void spawnFood(Point *food, Snake *snake);

int main(int argc, char *argv[]) {
    // SDL initialization
    SDL_Window *window = NULL;
    SDL_Renderer *renderer = NULL;
    TTF_Font *font = NULL;
    initializeSDL(&window, &renderer, &font);

    // Initialize SDL_image
    if (IMG_Init(IMG_INIT_PNG) != IMG_INIT_PNG) {
        printf("SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError());
        cleanup(window, renderer, NULL, NULL, NULL, font);
        return -1;
    }

    // Load textures
    SDL_Texture *bgTexture = loadTexture(renderer, backgroundPath);
    if (!bgTexture) {
        printf("Failed to load background texture!\n");
        cleanup(window, renderer, NULL, NULL, NULL, font);
        return -1;
    }

    SDL_Texture *snakeTexture = loadTexture(renderer, snakeTexturePath);
    if (!snakeTexture) {
        printf("Failed to load snake texture!\n");
        cleanup(window, renderer, bgTexture, NULL, NULL, font);
        return -1;
    }

    SDL_Texture *foodTexture = loadTexture(renderer, foodTexturePath);
    if (!foodTexture) {
        printf("Failed to load food texture!\n");
        cleanup(window, renderer, bgTexture, snakeTexture, NULL, font);
        return -1;
    }

    // Display the introduction screen
    bool startGame = false;
    SDL_Event event;
    while (!startGame) {
        while (SDL_PollEvent(&event)) {             // to check which key pressed
            if (event.type == SDL_QUIT) {
                cleanup(window, renderer, bgTexture, snakeTexture, foodTexture, font);
                return 0;
            } else if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_RETURN) {
                startGame = true; // Start the game when Enter is pressed
            }
        }

        SDL_RenderClear(renderer);
        renderIntroScreen(renderer, font);
        SDL_RenderPresent(renderer);
    }

    // Game variables
    Snake snake = {{{10, 10}}, 2, {1, 0}}; // Initial snake position and direction
    Point food = {15, 15};                   // Initial food position
    bool running = true;
    int delay = 100;                       // Game loop delay

    srand((unsigned int)time(NULL));

    // Game loop
    while (running) {
        // Handle events
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            } else if (event.type == SDL_KEYDOWN) {
                switch (event.key.keysym.sym) {
                    case SDLK_UP: if (snake.direction.y == 0) snake.direction = (Point){0, -1}; break;
                    case SDLK_DOWN: if (snake.direction.y == 0) snake.direction = (Point){0, 1}; break;
                    case SDLK_LEFT: if (snake.direction.x == 0) snake.direction = (Point){-1, 0}; break;
                    case SDLK_RIGHT: if (snake.direction.x == 0) snake.direction = (Point){1, 0}; break;
                }
            }
        }

        // Move the snake
        moveSnake(&snake);

        // Check for collisions with borders
        if (checkBorderCollision(&snake)) {
            renderGameOver(renderer, font);
            SDL_RenderPresent(renderer);
            SDL_Delay(2000);
            running = false;
            break;
        }

        // Check for collisions with the snake itself
        if (checkSelfCollision(&snake)) {
            renderGameOver(renderer, font);
            SDL_RenderPresent(renderer);
            SDL_Delay(2000);
            running = false;
            break;
        }

        // Check if the snake eats food
        if (checkCollision(&snake, &food)) {
            snake.length++;
            spawnFood(&food, &snake);
        }

        // Render game elements
        SDL_RenderClear(renderer);
        renderBackground(renderer, bgTexture);
        renderSnake(renderer, &snake, snakeTexture);
        renderFood(renderer, &food, foodTexture);
        renderScore(renderer, font, snake.length - 2);                // set score if length increase
        renderBorders(renderer);
        SDL_RenderPresent(renderer);

        SDL_Delay(delay);
    }

    // Cleanup and exit
    cleanup(window, renderer, bgTexture, snakeTexture, foodTexture, font);
    return 0;
}
void renderIntroScreen(SDL_Renderer *renderer, TTF_Font *font) {
    SDL_Color textColor = {0, 255, 0, 0};

    SDL_Surface *titleSurface = TTF_RenderText_Solid(font, "Welcome to COD", textColor);
    SDL_Texture *titleTexture = SDL_CreateTextureFromSurface(renderer, titleSurface);
    SDL_Rect titleRect = {
        (SCREEN_WIDTH - titleSurface->w) / 2,
        SCREEN_HEIGHT / 4,
        titleSurface->w,
        titleSurface->h
    };
    SDL_RenderCopy(renderer, titleTexture, NULL, &titleRect);

    SDL_Surface *promptSurface = TTF_RenderText_Solid(font, "Press ENTER to Start", textColor);
    SDL_Texture *promptTexture = SDL_CreateTextureFromSurface(renderer, promptSurface);
    SDL_Rect promptRect = {
        (SCREEN_WIDTH - promptSurface->w) / 2,
        SCREEN_HEIGHT / 2,
        promptSurface->w,
        promptSurface->h
    };
    SDL_RenderCopy(renderer, promptTexture, NULL, &promptRect);

    SDL_FreeSurface(titleSurface);
    SDL_DestroyTexture(titleTexture);
    SDL_FreeSurface(promptSurface);
    SDL_DestroyTexture(promptTexture);
}
// Function implementations
SDL_Texture* loadTexture(SDL_Renderer *renderer, const char *file) {
    SDL_Surface *loadedSurface = IMG_Load(file);
    if (loadedSurface == NULL) {
        printf("Unable to load image %s! SDL_image Error: %s\n", file, IMG_GetError());
        return NULL;
    }

    SDL_Texture *newTexture = SDL_CreateTextureFromSurface(renderer, loadedSurface);
    if (newTexture == NULL) {
        printf("Unable to create texture from surface! SDL Error: %s\n", SDL_GetError());
    }

    SDL_FreeSurface(loadedSurface);
    return newTexture;
}

void initializeSDL(SDL_Window **window, SDL_Renderer **renderer, TTF_Font **font) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL Initialization failed: %s\n", SDL_GetError());
        exit(1);
    }
    if (TTF_Init() == -1) {
        printf("SDL_ttf Initialization failed: %s\n", TTF_GetError());
        SDL_Quit();
        exit(1);
    }

    *window = SDL_CreateWindow("SDL Snake Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    if (!*window) {
        printf("Window creation failed: %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
    }

    *renderer = SDL_CreateRenderer(*window, -1, SDL_RENDERER_ACCELERATED);
    if (!*renderer) {
        printf("Renderer creation failed: %s\n", SDL_GetError());
        SDL_DestroyWindow(*window);
        SDL_Quit();
        exit(1);
    }

    // Load font for rendering text
    *font = TTF_OpenFont(fontPath, 24); // Load a font with size 24
    if (*font == NULL) {
        printf("Failed to load font! SDL_ttf Error: %s\n", TTF_GetError());
        SDL_Quit();
        exit(1);
    }
}

void cleanup(SDL_Window *window, SDL_Renderer *renderer, SDL_Texture *bgTexture, SDL_Texture *snakeTexture, SDL_Texture *foodTexture, TTF_Font *font) {
    SDL_DestroyTexture(bgTexture);
    SDL_DestroyTexture(snakeTexture);
    SDL_DestroyTexture(foodTexture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();
}

void renderBackground(SDL_Renderer *renderer, SDL_Texture *bgTexture) {
    SDL_Rect destRect = {0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};
    SDL_RenderCopy(renderer, bgTexture, NULL, &destRect); // Draw the background image
}

void renderSnake(SDL_Renderer *renderer, Snake *snake, SDL_Texture *snakeTexture) {
    for (int i = 0; i < snake->length; i++) {
        SDL_Rect destRect = {snake->body[i].x * GRID_SIZE, snake->body[i].y * GRID_SIZE, GRID_SIZE, GRID_SIZE};
        SDL_RenderCopy(renderer, snakeTexture, NULL, &destRect); // Draw the snake texture
    }
}

void renderFood(SDL_Renderer *renderer, Point *food, SDL_Texture *foodTexture) {
    int foodSize = GRID_SIZE * 2;  // Food size is double the grid size
    SDL_Rect destRect = {food->x * GRID_SIZE, food->y * GRID_SIZE, foodSize, foodSize};
    SDL_RenderCopy(renderer, foodTexture, NULL, &destRect); // Draw the food texture
}

void renderScore(SDL_Renderer *renderer, TTF_Font *font, int score) {
    char scoreText[20];
    sprintf(scoreText, "Score: %d", score);

    SDL_Color textColor = {255, 255, 255, 255}; // White text color
    SDL_Surface *textSurface = TTF_RenderText_Solid(font, scoreText, textColor);
    SDL_Texture *textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);

    SDL_Rect textRect = {10, 10, textSurface->w, textSurface->h};
    SDL_RenderCopy(renderer, textTexture, NULL, &textRect); // Render score text

    SDL_FreeSurface(textSurface);
    SDL_DestroyTexture(textTexture);
}

void renderGameOver(SDL_Renderer *renderer, TTF_Font *font) {
    SDL_Color textColor = {255, 0, 0, 255}; // Red text color
    SDL_Surface *textSurface = TTF_RenderText_Solid(font, "Game Over", textColor);
    SDL_Texture *textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);

    // Rectangle for background of "Game Over"
    SDL_Rect rect = {
        (SCREEN_WIDTH - textSurface->w) / 2 - 10,  // Padding around text
        (SCREEN_HEIGHT - textSurface->h) / 2 - 10, // Padding around text
        textSurface->w + 20, // Extra padding on the sides
        textSurface->h + 20  // Extra padding on the top and bottom
    };

    // Draw the background rectangle (filled with black)
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderFillRect(renderer, &rect);

    // Render "Game Over" text on top of the rectangle
    SDL_Rect textRect = {
        (SCREEN_WIDTH - textSurface->w) / 2,
        (SCREEN_HEIGHT - textSurface->h) / 2,
        textSurface->w,
        textSurface->h
    };

    SDL_RenderCopy(renderer, textTexture, NULL, &textRect); // Render "Game Over" text

    SDL_FreeSurface(textSurface);
    SDL_DestroyTexture(textTexture);
}

void renderBorders(SDL_Renderer *renderer) {
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255); // White color for the border

    // Draw top border
    SDL_RenderDrawLine(renderer, 0, 0, SCREEN_WIDTH, 0);    //top-left corner of the screen

    // Draw bottom border
    SDL_RenderDrawLine(renderer, 0, SCREEN_HEIGHT - 1, SCREEN_WIDTH, SCREEN_HEIGHT - 1);

    // Draw left border
    SDL_RenderDrawLine(renderer, 0, 0, 0, SCREEN_HEIGHT);

    // Draw right border
    SDL_RenderDrawLine(renderer, SCREEN_WIDTH - 1, 0, SCREEN_WIDTH - 1, SCREEN_HEIGHT);
}

void moveSnake(Snake *snake) {
    for (int i = snake->length - 1; i > 0; i--) {
        snake->body[i] = snake->body[i - 1];
    }
    snake->body[0].x += snake->direction.x;
    snake->body[0].y += snake->direction.y;
}

bool checkCollision(Snake *snake, Point *food) {
    SDL_Rect snakeHeadRect = {
        snake->body[0].x * GRID_SIZE,
        snake->body[0].y * GRID_SIZE,
        GRID_SIZE, GRID_SIZE
    };
    SDL_Rect foodRect = {
        food->x * GRID_SIZE,
        food->y * GRID_SIZE,
        GRID_SIZE * 2, GRID_SIZE * 2  // Food hitbox is double the grid size
    };

    return SDL_HasIntersection(&snakeHeadRect, &foodRect);
}

bool checkSelfCollision(Snake *snake) {
    for (int i = 1; i < snake->length; i++) {
        if (snake->body[0].x == snake->body[i].x && snake->body[0].y == snake->body[i].y) {          // 0 is head index and i is body
            return true;
        }
    }
    return false;
}

bool checkBorderCollision(Snake *snake) {
    // Check if the snake's head touches any of the borders
    if (snake->body[0].x < 0 || snake->body[0].x >= SCREEN_WIDTH / GRID_SIZE ||
        snake->body[0].y < 0 || snake->body[0].y >= SCREEN_HEIGHT / GRID_SIZE) {
        return true;
    }
    return false;
}

void spawnFood(Point *food, Snake *snake) {
    bool validPosition;
    do {
        validPosition = true;
        food->x = rand() % (SCREEN_WIDTH / GRID_SIZE);          // % ensures food generate inside window
        food->y = rand() % (SCREEN_HEIGHT / GRID_SIZE);

        // Food hitbox
        SDL_Rect foodRect = {
            food->x * GRID_SIZE,
            food->y * GRID_SIZE,
            GRID_SIZE * 2, GRID_SIZE * 2
        };

        // Check if food intersects with snake
        for (int i = 0; i < snake->length; i++) {
            SDL_Rect snakeSegmentRect = {
                snake->body[i].x * GRID_SIZE,
                snake->body[i].y * GRID_SIZE,
                GRID_SIZE, GRID_SIZE
            };
            if (SDL_HasIntersection(&foodRect, &snakeSegmentRect)) {
                validPosition = false;
                break;
            }
        }
    } while (!validPosition);
}

